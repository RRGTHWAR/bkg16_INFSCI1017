package music;

public class Artist {
	String artistID;

	public String getArtistID() {
		return artistID;
	}

	public void setArtistID(String artistID) {
		this.artistID = artistID;
	}
	
	
}
